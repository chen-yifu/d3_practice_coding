A practice of using js and async programming that I'm learning to prepare for NLP co-op!

The tutorial that this practice came from (https://www.youtube.com/watch?v=_8V5o2UHG0E&t=1220s)
